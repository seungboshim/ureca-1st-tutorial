import React from "react";

export default function Third({ children }) {
  return <div style={{ color: "blue" }}>{children}</div>;
}
